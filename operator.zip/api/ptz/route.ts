import { NextResponse } from 'next/server';
import DigestClient from 'digest-fetch';

interface PTZRequest {
  camera: {
    type: 'axis' | 'hikvision';
    ip: string;
    user: string;
    pass: string;
  };
  command: 'move' | 'stop' | 'preset' | 'set_preset' | 'get_presets';
  pan?: number;   
  tilt?: number;  
  zoom?: number;  
  presetId?: number | string;
  presetName?: string;
}

export async function POST(request: Request) {
  try {
    const body: PTZRequest = await request.json();
    const { camera, command, pan = 0, tilt = 0, zoom = 0, presetId, presetName } = body;

    if (!camera || !camera.ip) return NextResponse.json({ error: 'Missing camera config' }, { status: 400 });

    const client = new DigestClient(camera.user, camera.pass);

    // --- PRESET SYNC LOGIC ---
    if (command === 'get_presets') {
      if (camera.type === 'axis') {
        const res = await client.fetch(`http://${camera.ip}/axis-cgi/com/ptz.cgi?query=presetposcam`, { cache: 'no-store' });
        const text = await res.text();
        const presets = text.split('\n')
          .filter(l => l.includes('='))
          .map(l => {
             const name = l.split('=')[1].trim();
             return { id: name, name: name }; 
          })
          .filter(p => p.name);
        return NextResponse.json({ success: true, presets });
      } else {
        const res = await client.fetch(`http://${camera.ip}/ISAPI/PTZCtrl/channels/1/presets`, { cache: 'no-store' });
        const text = await res.text();
        const matches = [...text.matchAll(/<id>(\d+)<\/id>[\s\S]*?<presetName>(.*?)<\/presetName>/g)];
        const presets = matches.map(m => {
            const decodedName = m[2].replace(/&amp;/g, '&').replace(/&lt;/g, '<').replace(/&gt;/g, '>');
            return { id: parseInt(m[1], 10), name: decodedName };
        }).filter(p => !p.name.startsWith('Preset '));
        return NextResponse.json({ success: true, presets });
      }
    }

    if (camera.type === 'axis') {
      return await handleAxisPTZ(client, camera.ip, command, pan, tilt, zoom, presetId, presetName);
    } else {
      return await handleHikvisionPTZ(client, camera.ip, command, pan, tilt, zoom, presetId, presetName);
    }
  } catch (error: any) {
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}

async function handleAxisPTZ(client: DigestClient, ip: string, command: string, pan: number, tilt: number, zoom: number, presetId?: number | string, presetName?: string) {
  let url = `http://${ip}/axis-cgi/com/ptz.cgi?`;
  if (command === 'stop') url += 'continuouspantiltmove=0,0&continuouszoommove=0';
  else if (command === 'preset' && presetId !== undefined) url += `imagetg=${encodeURIComponent(presetId)}`;
  else if (command === 'set_preset' && presetName) url += `setserverpresetname=${encodeURIComponent(presetName)}`;
  else {
    const params = [];
    if (pan !== 0 || tilt !== 0) params.push(`continuouspantiltmove=${Math.round(pan * 100)},${Math.round((tilt * -1) * 100)}`);
    if (zoom !== 0) params.push(`continuouszoommove=${Math.round(zoom * 100)}`);
    if (params.length === 0) return NextResponse.json({ success: true });
    url += params.join('&');
  }
  const res = await client.fetch(url, { method: 'GET', cache: 'no-store' });
  if (!res.ok) throw new Error(`Axis error ${res.status}`);
  return NextResponse.json({ success: true });
}

async function handleHikvisionPTZ(client: DigestClient, ip: string, command: string, pan: number, tilt: number, zoom: number, presetId?: number | string, presetName?: string) {
  let url = `http://${ip}/ISAPI/PTZCtrl/channels/1/continuous`;
  let method = 'PUT';
  let xmlPayload = '';

  if (command === 'stop') {
    xmlPayload = `<?xml version="1.0" encoding="UTF-8"?><PTZData version="2.0" xmlns="http://www.isapi.org/ver20/XMLSchema"><pan>0</pan><tilt>0</tilt><zoom>0</zoom></PTZData>`;
  } else if (command === 'preset' && presetId !== undefined) {
    url = `http://${ip}/ISAPI/PTZCtrl/channels/1/presets/${presetId}/goto`;
    method = 'PUT';
  } else if (command === 'set_preset' && presetId !== undefined) {
    url = `http://${ip}/ISAPI/PTZCtrl/channels/1/presets/${presetId}`;
    method = 'PUT';
    xmlPayload = `<?xml version="1.0" encoding="UTF-8"?><PTZPreset version="2.0" xmlns="http://www.isapi.org/ver20/XMLSchema"><id>${presetId}</id><presetName>${presetName || `Preset ${presetId}`}</presetName></PTZPreset>`;
  } else {
    xmlPayload = `<?xml version="1.0" encoding="UTF-8"?><PTZData version="2.0" xmlns="http://www.isapi.org/ver20/XMLSchema"><pan>${Math.round(pan * 100)}</pan><tilt>${Math.round(tilt * 100)}</tilt><zoom>${Math.round(zoom * 100)}</zoom></PTZData>`;
  }

  const res = await client.fetch(url, { method, headers: { 'Content-Type': 'application/xml' }, body: xmlPayload || undefined, cache: 'no-store' });
  if (!res.ok) throw new Error(`Hikvision error ${res.status}`);
  return NextResponse.json({ success: true });
}